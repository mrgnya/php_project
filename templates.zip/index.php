<?php 
session_start();
function render($replaces, $tpl_filename){
  $tpl = file_get_contents($tpl_filename);
  $tpl = strtr($tpl, $replaces);
  return $tpl;
};
    $db = new PDO('mysql:host=localhost;dbname=blog', 'root', '');
    $query = $db->query('SELECT id, title, preview, content, created, author FROM articles;');
    
    $result = $query->FETCHALL(PDO::FETCH_ASSOC);
    $page_html = '';
    foreach ($result as $e) {
             $replaces = [
                '{{ title }}' => $e['title'],
                '{{ content }}' => $e['content'],
                '{{ preview }}' => $e['preview'],
                '{{ created }}' => $e['created'],
                '{{ author }}' => $e['author']        
             ];
            $page_html .= render($replaces, 'templates/template.html');
        }
echo render([
    '{{ template }}' => $page_html ], 'templates/index.html');

if (isset($_REQUEST['login'])and(isset($_REQUEST['password']))){
    $login = strip_tags($_REQUEST['login']);
    $pwd = strip_tags($_REQUEST['password']);
    $_SESSION['username'] = $login;
    $_SESSION['password'] = $pwd;
            
            $query = $db->prepare('INSERT INTO users (username, pwd) VALUES (?,?);');
            $query->execute(array($login, $pwd ));
            echo json_encode(array(
                'status' => 'ok'
            ));
        }else {
            echo json_encode(array(
                'status' => 'error'
            ));
        }
?>